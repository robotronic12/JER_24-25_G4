package es.urjc.tchs.demorobotcolliseum.Chat;

public @interface JsonCreator {

}
