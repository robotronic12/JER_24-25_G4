var GlobalData = {
    playing : false,
    volumen : 0.03,
    volumenCambiado : false,
    ganador : 0,
    isInChat : false,
    isMaster : false,
    numPowerUps : 0,
    initPlay: true
}

var usuario = {
    username: " ", // Asigna el valor deseado.
    password: " ", // Asigna el valor deseado.
    color1: 0,
    color2: 0,
};


