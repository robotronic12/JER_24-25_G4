package es.urjc.tchs.demorobotcolliseum;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemorobotcolliseumApplicationTests {

	@Test
	void contextLoads() {
	}

}
